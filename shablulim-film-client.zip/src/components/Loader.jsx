import loaderGif from '../assets/images/loadergif.gif'
export const Loader = () => {
  return (
    <div className="preloader" >
      <img src={loaderGif} alt=""/>
    </div>
  )
}
